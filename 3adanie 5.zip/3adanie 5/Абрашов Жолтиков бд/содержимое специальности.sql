use Abrashov_Zoltikov_P36
SELECT *
FROM spec