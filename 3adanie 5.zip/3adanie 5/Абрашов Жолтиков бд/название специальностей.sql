use Abrashov_Zoltikov_P36
SELECT spec
FROM spec