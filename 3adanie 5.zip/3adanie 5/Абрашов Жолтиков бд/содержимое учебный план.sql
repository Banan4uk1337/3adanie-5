use Abrashov_Zoltikov_P36
SELECT *
FROM uch_plan