use Abrashov_Zoltikov_P36
SELECT *
FROM groops, students
where n_Groop1 in (2921 , 3952 , 4841)