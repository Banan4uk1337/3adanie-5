use Abrashov_Zoltikov_P36
create table spec(
kod_spec int primary key not null,
spec varchar(60)
);