use Abrashov_Zoltikov_P36
SELECT *
FROM Sessia, students
where Mark=2 AND N_zach=3