use Abrashov_Zoltikov_P36
SELECT n_Groop, disciplina 
FROM uch_plan, groops