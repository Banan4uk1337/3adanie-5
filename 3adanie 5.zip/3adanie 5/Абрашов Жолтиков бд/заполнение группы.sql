use Abrashov_Zoltikov_P36
insert groops values
('1','1'),
('2','2'),
('3','3'),
('4','4'),
('5','5');