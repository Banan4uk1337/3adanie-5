use Abrashov_Zoltikov_P36
SELECT *
FROM students
where Last_name LIKE '�%'