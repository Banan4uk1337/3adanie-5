use Abrashov_Zoltikov_P36
SELECT Discipline, Data_ex
FROM Sessia